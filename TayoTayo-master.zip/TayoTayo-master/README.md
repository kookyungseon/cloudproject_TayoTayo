<h1>개인 맞춤형 주차 관리, 공유 시스템</h1>

<h3>개발기간</h3>
2023년 1월 3일 ~ 2023년 2월 16일
</br></br>

<h3>개발툴</h3>

<img alt="Html" src ="https://img.shields.io/badge/Django-092E20.svg?&style=for-the-badge&logo=Django&logoColor=white"/> <img alt="Html" src ="https://img.shields.io/badge/Python-3776AB.svg?&style=for-the-badge&logo=Python&logoColor=white"/> <img alt="Html" src ="https://img.shields.io/badge/MySQL-4479A1.svg?&style=for-the-badge&logo=MySQL&logoColor=white"/>
</br></br>

